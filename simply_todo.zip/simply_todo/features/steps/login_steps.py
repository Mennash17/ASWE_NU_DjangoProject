from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.by import By
from django.contrib.auth.models import User
from django.test import Client
import time

@given('I am on the login page')
def step_impl(context):
    context.browser = webdriver.Chrome()
    context.browser.get('http://127.0.0.1:8000/login/')
    time.sleep(1)

@when('I enter a valid username and password')
def step_impl(context):
    # Make sure the user exists
    User.objects.create_user(username='testuser', password='TtesTtPass')
    context.browser.find_element(By.NAME, 'username').send_keys('testuser')
    context.browser.find_element(By.NAME, 'password').send_keys('TtesTtPass')

@when('I press the login button')
def step_impl(context):
    context.browser.find_element(By.XPATH, "//button[@type='submit']").click()
    time.sleep(2)

@then('I should see the dashboard')
def step_impl(context):
    assert "dashboard" in context.browser.page_source.lower() or "todo" in context.browser.title.lower()
    context.browser.quit()
